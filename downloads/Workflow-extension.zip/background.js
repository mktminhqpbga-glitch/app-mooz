importScripts('chrome-remote-protocol.js','chrome-remote-diagnostics.js','chrome-relay-channel.js');
importScripts('desktop/chrome-relay-worker.js');
importScripts('desktop/ai-activity-worker.js');
